const logo = require('admin-lte/dist/img/AdminLTELogo.png');

const user1 = require('admin-lte/dist/img/user1-128x128.jpg');
const user2 = require('admin-lte/dist/img/user2-160x160.jpg');
const user3 = require('admin-lte/dist/img/user3-128x128.jpg');
const user4 = require('admin-lte/dist/img/user4-128x128.jpg');
const user5 = require('admin-lte/dist/img/user5-128x128.jpg');
const user6 = require('admin-lte/dist/img/user6-128x128.jpg');
const user7 = require('admin-lte/dist/img/user7-128x128.jpg');
const user8 = require('admin-lte/dist/img/user8-128x128.jpg');

export { logo, user1, user2, user3, user4, user5, user6, user7, user8 };
